<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_PatrickM_traveler
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		<div class="row bg-dark text-center">
			<div class="w-100 p-3">
				<h4 class="text-white"><?php bloginfo( 'name' ); ?></h4>
			</div>
			<div class="col p-3">
				<a class="text-white" href="<?php echo esc_url( __( 'https://wordpress.org/', 'cr12_PatrickM_traveler' ) ); ?>">
				</a>
			</div>
			<div class=" col-12 p-3 text-white">
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf('cr12_PatrickM_traveler');
				?>
			</div>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
