
<?php get_header(); ?>

<div class="container">
        
<div class="row">
        
                <img src="https://imgl.krone.at/scaled/761111/v28ef6e/full.jpg" class="col-12">

</div>

<?php get_footer(); ?>