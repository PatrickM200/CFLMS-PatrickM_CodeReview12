<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_PatrickM_traveler
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>

	<!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <style type="text/css" media="screen">
    	.headline{
    		position: absolute;
    		top: 8%;
    	}    	
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'cr12_PatrickM_traveler' ); ?></a>

	<header id="masthead" class="site-header">
		<div class="site-branding headline w-100">
			<?php
			the_custom_logo();
			if ( is_front_page() && is_home() ) :
				?>
				<h1 class="site-title d-none d-lg-block display-2 text-white text-center"><?php bloginfo( 'name' ); ?></h1>
				<?php
			else :
				?>
				<h1 class="site-title d-none d-lg-block display-2 text-white text-center"><?php bloginfo( 'name' ); ?></h1>
				<?php
			endif;
			$cr12_PatrickM_traveler_description = get_bloginfo( 'description', 'display' );
			if ( $cr12_PatrickM_traveler_description || is_customize_preview() ) :
				?>
				<h4 class="site-description text-white ml-3"><?php echo $cr12_PatrickM_traveler_description; /* WPCS: xss ok. */ ?></h4>
			<?php endif; ?>
		</div><!-- .site-branding -->

		<!-- #site-navigation -->
		<?php //if ( get_header_image() ) : ?>
			<div class="container-fluid">
				<div class="row">
					<img src="<?php esc_url( header_image() ); ?>" width="100%" alt="">
				</div>
			</div>
		<?php //endif; // End header image check. ?>
		
		<nav class="navbar navbar-expand-sm bg-dark navbar-dark bg-info" role="navigation" id="navi">
			
			<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				<?php
				wp_nav_menu( array(
					'theme_location'    => 'primary',
					'depth'             => 2, // 1 = no dropdowns, 2 = dropdown
					'container'         => 'div',
					'container_class'   => 'collapse navbar-collapse',
					'container_id'      => 'bs-example-navbar-collapse-1',
					'menu_class'        => 'nav navbar-nav',
					'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
					'walker'            => new WP_Bootstrap_Navwalker(),
				) );
				?>
			</div>
		</nav>
	</header><!-- #masthead -->

	<div id="content" class="site-content">
